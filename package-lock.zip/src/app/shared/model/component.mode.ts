export class ComponentClass {
    x: number;
    y: number;
    objectClass: string;
    id: string;
    key: string = "";
    selected: Array<string>;
    selectedIn: Array<string> = [];
    
}